# Rysa — Cleaner + Modo Gamer (Kotlin + Compose)

Projeto nativo Android 10+ (API 29–34), MVVM, tema roxo neon #A855F7.

## O que está pronto
- `AndroidManifest.xml` com ForegroundService + overlay + permissões
- `service/RysaForegroundService.kt` — notificação com ações Limpar RAM / Gamer / Ant Lag / Sair
- `cleaner/CleanerEngine.kt` — StorageManager/StorageStatsManager + killBackgroundProcesses + UsageStats
- `overlay/FpsOverlayService.kt` — overlay com Choreographer, baixo consumo
- `ui/` — Compose: Home (RAM/CPU/poções/gráfico), Config (apps importantes), Sobre

## Como gerar o APK (2 opções)

### Opção A — GitHub Actions (sem instalar nada)
1. Crie um repositório no GitHub e envie esta pasta `rysa/` + `.github/`
2. Aba Actions → aguarde "Build Rysa APK" → baixe `rysa-debug-apk`
3. Instale no celular e conceda: Uso de dados/Usage Stats + Sobrepor a outros apps

### Opção B — Android Studio
1. Android Studio Hedgehog+ → Open → pasta `rysa/`
2. Deixe sincronizar (Gradle 8.4, AGP 8.3.2, Kotlin 1.9.23)
3. Run ▶ ou Build → Build APK(s)

## Permissões concedidas manualmente
- `PACKAGE_USAGE_STATS`: Config → Apps → Acesso especial → Acesso a dados de uso → Rysa → permitir
- `SYSTEM_ALERT_WINDOW`: o botão "Mostrar FPS flutuante" abre a tela certa
- Limpeza de cache total sem root não é permitida pelo Android 10+; o app estima cache via StorageStatsManager e mata processos + sugere limpeza do sistema.
