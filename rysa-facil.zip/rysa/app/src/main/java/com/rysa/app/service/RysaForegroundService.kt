package com.rysa.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.rysa.app.MainActivity
import com.rysa.app.cleaner.CleanerEngine
import com.rysa.app.overlay.FpsOverlayService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class RysaForegroundService : Service() {

    companion object {
        const val CHANNEL_ID = "rysa_service"
        const val NOTIF_ID = 1001
        const val ACT_CLEAN = "rysa.ACT_CLEAN"
        const val ACT_GAMER = "rysa.ACT_GAMER"
        const val ACT_ANTILAG = "rysa.ACT_ANTILAG"
        const val ACT_EXIT = "rysa.ACT_EXIT"

        fun startCmd(ctx: android.content.Context, action: String): Intent =
            Intent(ctx, RysaForegroundService::class.java).setAction(action)
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var engine: CleanerEngine

    override fun onCreate() {
        super.onCreate()
        engine = CleanerEngine(this)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotif("Rysa ativo • toque para otimizar"))
        when (intent?.action) {
            ACT_CLEAN -> runClean("Hibernacao geral concluida")
            ACT_GAMER -> runClean("Modo Gamer ativado", gamer = true)
            ACT_ANTILAG -> runClean("Ant Lag ativado", antiLag = true)
            ACT_EXIT -> {
                stopService(Intent(this, FpsOverlayService::class.java))
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
        }
        return START_STICKY
    }

    private fun runClean(msg: String, gamer: Boolean = false, antiLag: Boolean = false) {
        scope.launch {
            try {
                val protected = setOf(
                    "com.android.dialer", "com.android.mms", "com.whatsapp",
                    "com.android.systemui", "com.android.phone"
                )
                val res = when {
                    gamer -> engine.gamerBoost(protected)
                    antiLag -> engine.antiLag(protected)
                    else -> engine.hibernateAll(protected)
                }
                updateNotif("$msg • ${res.killedPackages.size} apps pausados")
            } catch (_: Exception) {}
        }
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java) ?: return
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Rysa", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun pIntent(action: String, req: Int): PendingIntent =
        PendingIntent.getService(this, req, startCmd(this, action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    private fun buildNotif(text: String): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Rysa ⚡")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(openApp)
            .setOngoing(true)
            .addAction(0, "Limpar RAM", pIntent(ACT_CLEAN, 1))
            .addAction(0, "Gamer", pIntent(ACT_GAMER, 2))
            .addAction(0, "Ant Lag", pIntent(ACT_ANTILAG, 3))
            .addAction(0, "Sair", pIntent(ACT_EXIT, 4))
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .build()
    }

    private fun updateNotif(text: String) {
        val nm = getSystemService(NotificationManager::class.java) ?: return
        nm.notify(NOTIF_ID, buildNotif(text))
    }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}
