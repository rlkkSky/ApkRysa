package com.rysa.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF0A0A0A)
val Card = Color(0xFF16121E)
val Neon = Color(0xFFA855F7)
val NeonLight = Color(0xFFD8B4FE)
val Muted = Color(0xFF9CA3AF)

private val Scheme = darkColorScheme(
    background = Bg, surface = Card, surfaceVariant = Card,
    primary = Neon, onPrimary = Color.White,
    secondary = NeonLight, onBackground = Color.White, onSurface = Color.White
)

@Composable
fun RysaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
