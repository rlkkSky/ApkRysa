package com.rysa.app.overlay

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Choreographer
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class FpsOverlayService : Service(), Choreographer.FrameCallback {

    private var wm: WindowManager? = null
    private var view: TextView? = null
    private var lastNanos = 0L
    private var frames = 0
    private var lastReport = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (!android.provider.Settings.canDrawOverlays(this)) { stopSelf(); return }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        view = TextView(this).apply {
            text = "— FPS"
            textSize = 13f
            setPadding(18, 10, 18, 10)
            setBackgroundColor(0xCC0A0A0A.toInt())
            setTextColor(0xFFD8B4FE.toInt())
        }
        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 16; y = 120 }
        wm?.addView(view, params)
        lastNanos = System.nanoTime()
        lastReport = lastNanos
        Choreographer.getInstance().postFrameCallback(this)
    }

    override fun doFrame(frameTimeNanos: Long) {
        frames++
        val now = System.nanoTime()
        if (now - lastReport >= 1_000_000_000L) {
            val fps = (frames * 1e9 / (now - lastReport)).toInt()
            view?.text = "$fps FPS"
            frames = 0
            lastReport = now
        }
        Choreographer.getInstance().postFrameCallback(this)
    }

    override fun onDestroy() {
        try { Choreographer.getInstance().removeFrameCallback(this) } catch (_: Exception) {}
        try { view?.let { wm?.removeView(it) } } catch (_: Exception) {}
        super.onDestroy()
    }
}
