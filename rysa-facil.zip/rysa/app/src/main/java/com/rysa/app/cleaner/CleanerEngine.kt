package com.rysa.app.cleaner

import android.app.ActivityManager
import android.app.usage.StorageStatsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.storage.StorageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class CleanResult(
    val killedPackages: List<String>,
    val cacheBytesEstimate: Long,
    val durationMs: Long
)

class CleanerEngine(private val context: Context) {

    fun installedPackages(): List<AppInfo> {
        val pm = context.packageManager
        return pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { (it.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) == 0 }
            .map { AppInfo(it.packageName, pm.getApplicationLabel(it).toString()) }
            .sortedBy { it.label.lowercase() }
    }

    suspend fun estimateCache(): Long = withContext(Dispatchers.IO) {
        if (Build.VERSION.SDK_INT < 26) return@withContext 0L
        try {
            val ssm = context.getSystemService(StorageStatsManager::class.java) ?: return@withContext 0L
            val sm = context.getSystemService(StorageManager::class.java) ?: return@withContext 0L
            var total = 0L
            for (volume in sm.storageVolumes) {
                try {
                    val uuid = volume.uuid?.let { java.util.UUID.fromString(it) }
                        ?: StorageManager.UUID_DEFAULT
                    val uid = context.applicationInfo.uid
                    total += ssm.queryStatsForUid(uuid, uid).cacheBytes
                } catch (_: Exception) {}
            }
            total
        } catch (_: Exception) { 0L }
    }

    suspend fun gamerBoost(protected: Set<String>): CleanResult = withContext(Dispatchers.IO) {
        val t0 = System.currentTimeMillis()
        val cache = estimateCache()
        val killed = killBackground(protected)
        boostForegroundPriority()
        CleanResult(killed, cache, System.currentTimeMillis() - t0)
    }

    suspend fun hibernateAll(protected: Set<String>): CleanResult = withContext(Dispatchers.IO) {
        val t0 = System.currentTimeMillis()
        val killed = killBackground(protected, aggressive = true)
        CleanResult(killed, 0L, System.currentTimeMillis() - t0)
    }

    suspend fun antiLag(protected: Set<String>): CleanResult = withContext(Dispatchers.IO) {
        val t0 = System.currentTimeMillis()
        val foreground = foregroundPackage()
        val keep = protected + foreground + context.packageName
        val killed = killBackground(keep, aggressive = true)
        CleanResult(killed, 0L, System.currentTimeMillis() - t0)
    }

    private fun killBackground(protected: Set<String>, aggressive: Boolean = false): List<String> {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val pm = context.packageManager
        val killed = mutableListOf<String>()
        val procs = am.runningAppProcesses ?: return emptyList()
        for (p in procs) {
            val pkg = pkgForProcess(p.processName) ?: continue
            if (pkg in protected || pkg == context.packageName) continue
            if (p.importance <= ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND && !aggressive) continue
            try {
                if (isUserApp(pkg)) {
                    am.killBackgroundProcesses(pkg)
                    killed.add(pkg)
                }
            } catch (_: Exception) {}
        }
        return killed.distinct()
    }

    private fun boostForegroundPriority() {
        try {
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_DISPLAY)
        } catch (_: Exception) {}
    }

    private fun foregroundPackage(): String? {
        return try {
            val usm = context.getSystemService(UsageStatsManager::class.java) ?: return null
            val now = System.currentTimeMillis()
            val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 60_000, now)
            stats.maxByOrNull { it.lastTimeUsed }?.packageName
        } catch (_: Exception) { null }
    }

    private fun pkgForProcess(processName: String): String? {
        return try {
            context.packageManager.getApplicationInfo(processName.split(":")[0], 0).packageName
        } catch (_: Exception) { null }
    }

    private fun isUserApp(pkg: String): Boolean {
        return try {
            val info = context.packageManager.getApplicationInfo(pkg, 0)
            (info.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) == 0 ||
                (info.flags and android.content.pm.ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
        } catch (_: Exception) { false }
    }
}

data class AppInfo(val packageName: String, val label: String)
