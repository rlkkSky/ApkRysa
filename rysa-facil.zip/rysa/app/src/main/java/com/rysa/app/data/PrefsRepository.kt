package com.rysa.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("rysa_prefs")

object PrefsKeys {
    val PROTECTED_APPS = stringSetPreferencesKey("protected_apps")
    val FPS_OVERLAY = booleanPreferencesKey("fps_overlay")
    val GAMER_MODE = booleanPreferencesKey("gamer_mode")
}

class PrefsRepository(private val context: Context) {
    val defaultProtected = setOf(
        "com.android.dialer", "com.android.mms", "com.whatsapp",
        "com.android.systemui", "com.android.phone", "com.google.android.gms"
    )

    val protectedApps: Flow<Set<String>> =
        context.dataStore.data.map { it[PrefsKeys.PROTECTED_APPS] ?: defaultProtected }

    val fpsOverlayEnabled: Flow<Boolean> =
        context.dataStore.data.map { it[PrefsKeys.FPS_OVERLAY] ?: false }

    suspend fun setProtected(pkg: String, protect: Boolean) {
        context.dataStore.edit { prefs ->
            val cur = (prefs[PrefsKeys.PROTECTED_APPS] ?: defaultProtected).toMutableSet()
            if (protect) cur.add(pkg) else cur.remove(pkg)
            prefs[PrefsKeys.PROTECTED_APPS] = cur
        }
    }

    suspend fun setFpsOverlay(enabled: Boolean) {
        context.dataStore.edit { it[PrefsKeys.FPS_OVERLAY] = enabled }
    }
}
