package com.rysa.app.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rysa.app.cleaner.AppInfo
import com.rysa.app.cleaner.CleanerEngine
import com.rysa.app.data.PrefsRepository
import com.rysa.app.overlay.FpsOverlayService
import com.rysa.app.service.RysaForegroundService
import com.rysa.app.ui.HomeViewModel
import com.rysa.app.ui.theme.Card
import com.rysa.app.ui.theme.Muted
import com.rysa.app.ui.theme.Neon
import com.rysa.app.ui.theme.NeonLight
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(vm: HomeViewModel) {
    val ctx = LocalContext.current
    val state by vm.state.collectAsState()
    LaunchedEffect(Unit) { vm.startSampling(ctx) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Color(0xFF0A0A0A)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card {
                Text("⚡ RYSA", color = NeonLight, fontSize = 22.sp, fontWeight = FontWeight.Black)
                Text("Cleaner + Modo Gamer", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                Text("RAM ${state.ramUsedPct}% • ${state.ramText}", color = Color.White, fontSize = 14.sp)
                LinearProgressIndicator(
                    progress = { state.ramUsedPct / 100f },
                    modifier = Modifier.fillMaxWidth().height(10.dp).padding(top = 8.dp),
                    color = Neon, trackColor = Color(0xFF2A2140)
                )
                Spacer(Modifier.height(8.dp))
                Text("CPU ${state.cpuText}", color = Muted, fontSize = 13.sp)
                if (state.lastResult.isNotEmpty())
                    Text("✅ ${state.lastResult}", color = NeonLight, fontSize = 13.sp)
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PotionButton("🎮", "Modo\nGamer", Modifier.weight(1f), busy = state.busy) {
                    ctx.startForegroundService(Intent(ctx, RysaForegroundService::class.java).setAction(RysaForegroundService.ACT_GAMER))
                    vm.run(ctx, "gamer")
                }
                PotionButton("🧊", "Ant\nLag", Modifier.weight(1f), busy = state.busy) {
                    ctx.startForegroundService(Intent(ctx, RysaForegroundService::class.java).setAction(RysaForegroundService.ACT_ANTILAG))
                    vm.run(ctx, "antilag")
                }
                PotionButton("🧪", "Hibernar\nTudo", Modifier.weight(1f), busy = state.busy) {
                    ctx.startForegroundService(Intent(ctx, RysaForegroundService::class.java).setAction(RysaForegroundService.ACT_CLEAN))
                    vm.run(ctx, "clean")
                }
            }
        }
        item {
            Card {
                Text("Histórico de limpeza", color = Color.White, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth().height(90.dp), verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val max = (state.history.maxOrNull() ?: 1).coerceAtLeast(1)
                    state.history.forEach { v ->
                        Box(Modifier.weight(1f).fillMaxHeight(v / max.toFloat())
                            .background(Neon, RoundedCornerShape(6.dp)))
                    }
                }
            }
        }
        item {
            OutlinedButton(onClick = {
                if (Settings.canDrawOverlays(ctx)) ctx.startService(Intent(ctx, FpsOverlayService::class.java))
                else ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }, modifier = Modifier.fillMaxWidth()) {
                Text("Mostrar FPS flutuante", color = NeonLight)
            }
        }
    }
}

@Composable
fun PotionButton(emoji: String, label: String, mod: Modifier, busy: Boolean, onClick: () -> Unit) {
    Button(onClick = onClick, enabled = !busy, modifier = mod.height(110.dp),
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Card)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(emoji, fontSize = 30.sp)
            Text(label, color = NeonLight, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun Card(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(18.dp)).padding(16.dp), content = content)
}

@Composable
fun SettingsScreen(prefs: PrefsRepository) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    var prot by remember { mutableStateOf<Set<String>>(emptySet()) }
    LaunchedEffect(Unit) {
        apps = CleanerEngine(ctx).installedPackages().take(200)
        prefs.protectedApps.collect { prot = it }
    }
    LazyColumn(Modifier.fillMaxWidth().background(Color(0xFF0A0A0A)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text("Apps importantes (nunca hibernar)", color = Color.White,
                fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("Toque para proteger/desproteger", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
        }
        items(apps) { app ->
            val checked = app.packageName in prot
            Row(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(12.dp)).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(app.label, color = Color.White, fontSize = 14.sp)
                    Text(app.packageName, color = Muted, fontSize = 11.sp)
                }
                Switch(checked = checked, onCheckedChange = {
                    scope.launch { prefs.setProtected(app.packageName, it) }
                })
            }
        }
    }
}

@Composable
fun AboutScreen() {
    Column(Modifier.fillMaxSize().background(Color(0xFF0A0A0A)).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text("🧪", fontSize = 64.sp)
        Text("Rysa v1.0.0", color = Color.White, fontWeight = FontWeight.Black, fontSize = 22.sp)
        Text("Cleaner + Hibernador + Modo Gamer\nAndroid 10–14 • Kotlin + Compose + MVVM",
            color = Muted, fontSize = 13.sp)
    }
}
