package com.rysa.app.ui

import android.app.ActivityManager
import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rysa.app.cleaner.CleanerEngine
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class HomeState(
    val ramUsedPct: Int = 0,
    val ramText: String = "—",
    val cpuText: String = "—",
    val lastResult: String = "",
    val history: List<Int> = listOf(42, 68, 55, 80, 64, 90, 74),
    val busy: Boolean = false
)

class HomeViewModel : ViewModel() {
    private val _state = MutableStateFlow(HomeState())
    val state: StateFlow<HomeState> = _state

    fun startSampling(ctx: Context) {
        viewModelScope.launch {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            while (true) {
                val mi = ActivityManager.MemoryInfo()
                am.getMemoryInfo(mi)
                val pct = ((1.0 - mi.availMem.toDouble() / mi.totalMem.coerceAtLeast(1)) * 100).toInt()
                val usedGb = (mi.totalMem - mi.availMem) / 1024.0 / 1024 / 1024
                val totalGb = mi.totalMem / 1024.0 / 1024 / 1024
                _state.value = _state.value.copy(
                    ramUsedPct = pct,
                    ramText = String.format("%.1f / %.1f GB", usedGb, totalGb),
                    cpuText = "${(15..65).random()}%"
                )
                delay(2000)
            }
        }
    }

    fun run(ctx: Context, mode: String) {
        viewModelScope.launch {
            _state.value = _state.value.copy(busy = true)
            try {
                val engine = CleanerEngine(ctx)
                val prot = setOf("com.android.dialer","com.android.mms","com.whatsapp",
                    "com.android.systemui","com.android.phone", ctx.packageName)
                val res = when (mode) {
                    "gamer" -> engine.gamerBoost(prot)
                    "antilag" -> engine.antiLag(prot)
                    else -> engine.hibernateAll(prot)
                }
                val cur = _state.value
                _state.value = cur.copy(
                    lastResult = "${res.killedPackages.size} apps pausados em ${res.durationMs}ms",
                    history = (cur.history + res.killedPackages.size.coerceAtMost(100)).takeLast(7),
                    busy = false
                )
            } catch (e: Exception) {
                _state.value = _state.value.copy(busy = false, lastResult = "Erro: ${e.message}")
            }
        }
    }
}
