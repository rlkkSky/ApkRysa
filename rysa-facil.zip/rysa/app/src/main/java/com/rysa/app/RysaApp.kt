package com.rysa.app

import android.app.Application
import com.rysa.app.data.PrefsRepository

class RysaApp : Application() {
    lateinit var prefs: PrefsRepository
    override fun onCreate() {
        super.onCreate()
        prefs = PrefsRepository(this)
    }
}
