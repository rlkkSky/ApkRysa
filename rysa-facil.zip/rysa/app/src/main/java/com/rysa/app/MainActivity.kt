package com.rysa.app

import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rysa.app.service.RysaForegroundService
import com.rysa.app.ui.HomeViewModel
import com.rysa.app.ui.screens.AboutScreen
import com.rysa.app.ui.screens.HomeScreen
import com.rysa.app.ui.screens.SettingsScreen
import com.rysa.app.ui.theme.RysaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            val svc = Intent(this, RysaForegroundService::class.java)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc)
            else startService(svc)
        } catch (_: Exception) {}
        setContent {
            RysaTheme {
                var tab by remember { mutableIntStateOf(0) }
                val app = application as RysaApp
                Scaffold(
                    bottomBar = {
                        NavigationBar(containerColor = androidx.compose.ui.graphics.Color(0xFF16121E)) {
                            NavigationBarItem(selected = tab == 0, onClick = { tab = 0 },
                                icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                            NavigationBarItem(selected = tab == 1, onClick = { tab = 1 },
                                icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Apps") })
                            NavigationBarItem(selected = tab == 2, onClick = { tab = 2 },
                                icon = { Icon(Icons.Default.Info, null) }, label = { Text("Sobre") })
                        }
                    }
                { pad ->
                    Surface(Modifier.padding(pad)) {
                        when (tab) {
                            0 -> { val vm: HomeViewModel = viewModel(); HomeScreen(vm) }
                            1 -> SettingsScreen(app.prefs)
                            else -> AboutScreen()
                        }
                    }
                }
            }
        }
    }
}
